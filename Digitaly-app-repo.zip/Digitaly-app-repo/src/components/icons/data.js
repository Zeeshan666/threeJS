import facebook from '../../assets/Updated Icons/Facebook-1.png'
import insta from '../../assets/Updated Icons/Instagram-1.png'
import discord from '../../assets/Updated Icons/Discord-1.png'
import dribble from '../../assets/Updated Icons/Dribble1.png'
import LinkedIn from '../../assets/Updated Icons/LinkedIn-1.png'
import behance from '../../assets/Updated Icons/Behance-1.png'
import tiktok from '../../assets/Updated Icons/Tiktok-1.png'
import twitter from '../../assets/Updated Icons/Twitter-1.png'


export const socialIcons = [
    { name: 'Facebook', icon: facebook },
    { name: 'Instagram', icon: insta },
    { name: 'Discord', icon: discord },
    { name: 'Dribbble', icon: dribble },
    { name: 'LinkedIn', icon: LinkedIn },
    { name: 'Behance', icon: behance },
    { name: 'TikTok', icon: tiktok },
    { name: 'Twitter', icon: twitter },
  ];