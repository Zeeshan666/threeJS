 {/* <Parallax speed={10}> */}
 <section
 className="rectangular-oval-white-prop"
 style={{ backgroundAttachment: "" }}
>
 <img className="w-75" src="./images/Rectangle 9521.png" alt />
</section>
{/* </Parallax> */}

{/* <Parallax speed={20}> */}
<section
 className="sec-1"
 style={{ border: "3px solid red", backgroundAttachment: "" }}
>
 {/* <Parallax speed={10}> */}
 <div className="container" style={{ border: "" }}>
   <div className="row align-items-center mt-5 mt-lg-0 pt-5 pt-lg-0">
     <div className="col-12 col-lg-6 text-center text-lg-start">
       <h1 className="display-5 text-white fw-bold">
         Construisons ensemble votre{" "}
         <span className="gradient-text-sec-1"> futur en ligne </span>
       </h1>
       <p className="text-white fs-5 fw-light">
         Découvrez nous au travers du digital
       </p>
     </div>
     <div className="col-12 col-lg-6 my-5 py-5 text-center text-lg-end">
      

       {/* <img className="img-fluid ellipse-img" src="./images/Ellipse 1.png" alt="Ellipse" /> */}
     </div>
   </div>
 </div>
 {/* </Parallax> */}
</section>
{/* </Parallax> */}

<section className="rectangular-oval-white-prop-2">
<img className="w-100" src="./images/Rectangle 9522.png" alt />
</section>